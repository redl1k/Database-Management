-- Название БД:
--- BuzdanovAndrian-KT1

-- Тема таблицы:
--- Дневник, в котором находятся названия дисциплин + преподаватели + оценки. 

-- 1.Подключение к postgresql:
$ sudo -u postgres psql

-- 2.Создание базы данных с названием 'buzdanovandrian_kt1':
$ postgres=# CREATE DATABASE buzdanovandrian_kt1;

-- 3.Переключаемся к базе данных:
$ postgres=# \c buzdanovandrian_kt1

-- 4. Создание таблицы diary3course, если создана такая таблица то скип:
CREATE TABLE IF NOT EXISTS diary3course(
	id_teacher BIGSERIAL NOT NULL PRIMARY KEY,
	teacher text NULL,
	name_discipline text NOT NULL UNIQUE,
	estimation integer CHECK (estimation >= 0)
);


-- 5. Добавляю данные в diary3course в следующие переменные:
INSERT INTO diary3course (id_teacher, name_discipline, teacher, estimation)
VALUES
(1, 'Linux', 'Kurilin T.', 115),
(2, 'Pentest', 'Sukhov A.', 100),
(3, 'English', 'Bar M.', 92),
(4, 'Explotation DC', 'Kolesnik E.', 100);

-- 6. Создание таблицы diary2course, если создана такая таблица то скип:
CREATE TABLE IF NOT EXISTS diary2course(
	id_teacher2 BIGSERIAL NOT NULL REFERENCES diary3course(id_teacher),
	name_discipline2 text NOT NULL UNIQUE,
	teacher2 text NULL,
	estimation2 integer CHECK (estimation2 >= 0) 
);

-- 7. Добавляю данные в diary2course в следующие переменные:
INSERT INTO diary2course(id_teacher2, name_discipline2, teacher2, estimation2)
VALUES 
(1, 'Linux', 'Kurilin T.', 100),
(2, 'English', 'Mironov V.', 91),
(3, 'Python', 'Ivanov V.', 100);

-- 8. Проверка таблицы, если я добавлю не верные данные:
INSERT INTO diary3course(id_teacher, name_discipline, teacher, estimation)
VALUES (1, 123, '123', -100);
ERROR:  new row for relation "diary3course" violates check constraint "diary3course_estimation_check"
DETAIL:  Failing row contains (1, 123, 123, -100).


----Итог
-- Вывод из таблицы diary3course:
--buzdanovandrian_kt1=# SELECT * FROM diary3course;
-- id_teacher |   teacher   | name_discipline | estimation 
--------------+-------------+-----------------+------------
--          1 | Kurilin T.  | Linux           |        115
--          2 | Sukhov A.   | Pentest         |        100
--          3 | Bar M.      | English         |         92
--          4 | Kolesnik E. | Explotation DC  |        100
--(4 rows)

--buzdanovandrian_kt1=# SELECT * FROM diary2course;
-- id_teacher2 | name_discipline2 |  teacher2  | estimation2 
-------------+------------------+------------+-------------
--           1 | Linux            | Kurilin T. |         100
--           2 | English          | Mironov V. |          91
--           3 | Python           | Ivanov V.  |         100
--(3 rows)

