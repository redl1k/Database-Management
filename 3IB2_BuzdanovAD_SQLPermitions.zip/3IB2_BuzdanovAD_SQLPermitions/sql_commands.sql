--- 1. Создание роли:
CREATE ROLE BuzdanovAD_admin;
--- CREATE ROLE

--- 2. Изменение роли: 
GRANT SELECT ON diary3course TO BuzdanovAD_admin;
--- GRANT
REVOKE INSERT ON diary3course FROM BuzdanovAD_admin;
--- REVOKE

---2.5 Захожу за роль BuzdanovAD_admin:
SET ROLE BuzdanovAD_admin;
--- SET

--- 3. Проверка роли:
SELECT * FROM diary3course;
---Вывелась вся таблица, как и нужно

INSERT INTO diary3course(name_discipline, teacher, estimation)
VALUES ('C++', 'MrFelex', 100);
--- Вывелась ошибка при добавлении значения в таблицу, как и нужнр:
--- ERROR:  permission denied for table diary3course

--- 4.Удаление роли:
--- Перед удалением роли, нужно лешить всех выданных прав:
REVOKE ALL PRIVILEGES ON ALL TABLES IN SCHEMA public FROM buzdanovad_admin;
--- REVOKE

--- Теперь удаляем саму роль:
DROP ROLE BuzdanovAD_admin;